package oct24;

public class ques37 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count = 1;
        
        do {
            System.out.println(count);
            count++;
        } while (count <= 10);

	}

}
